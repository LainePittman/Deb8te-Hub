from django.apps import AppConfig


class Deb8TeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'deb8te'
